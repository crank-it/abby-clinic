# Design System Configurator

A tool for configuring and exporting design systems as Markdown files for use with AI development skills.

## Features

- **Typography Selection**: Choose from 20+ Google Fonts for headings, body, and monospace
- **Colour Palette**: 6 preset palettes + full customisation for all CSS variables
- **Component Selection**: Pick which shadcn/ui components you need
- **Export**: Copy or download as `.md` file for your skill system

## Stack

- Next.js 14+ (App Router)
- Tailwind CSS
- TypeScript
- Lucide React icons

## Getting Started

```bash
# Install dependencies
npm install

# Run development server
npm run dev

# Build for production
npm run build
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

## Usage

1. **Typography Tab**: Select heading, body, and monospace fonts
2. **Colours Tab**: Choose a preset or customise each colour variable
3. **Components Tab**: Pick the shadcn/ui components you need
4. **Preview & Export Tab**: Copy markdown or download as file

## Output

The configurator exports a Markdown file containing:

- Font configuration with Next.js setup code
- CSS variables for colours (in HSL format)
- shadcn/ui install command for selected components
- Usage examples and quick reference

This file can be added to your AI development skill as a reference to ensure consistent styling across all generated code.

## Deploy

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone?repository-url=https://github.com/YOUR_USERNAME/design-system-configurator)

## Licence

MIT
